import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AgentDashboardRoutingModule } from './agent-dashboard-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AgentDashboardRoutingModule
  ]
})
export class AgentDashboardModule { }
