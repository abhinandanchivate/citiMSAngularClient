import {
  Directive,
  ElementRef,
  HostBinding,
  HostListener,
  Input,
  OnInit,
  Renderer2,
} from '@angular/core';

@Directive({
  selector: '[appHighlight]',
})
export class HighlightDirective implements OnInit {
  @Input()
  defaultColor: string = '';

  @Input()
  highlightColor: string = 'lime';

  @HostBinding('style.color')
  color: string = this.defaultColor;

  ngOnInit() {
    console.log('inside the directive');
    this.color = this.defaultColor;
  }

  @HostListener('mouseenter') mouseover() {
    this.renderer.setStyle(
      this.elementRef.nativeElement,
      'background-color',
      'blue'
    );

    this.color = this.highlightColor;
  }

  @HostListener('mouseleave') mouseleave() {
    this.renderer.setStyle(
      this.elementRef.nativeElement,
      'background-color',
      'transparent'
    );
    this.color = this.defaultColor;
  }

  constructor(private elementRef: ElementRef, private renderer: Renderer2) {}
}
