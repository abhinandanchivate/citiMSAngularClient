import { ParenthesisPipe } from './parenthesis.pipe';

describe('ParenthesisPipe', () => {
  it('create an instance', () => {
    const pipe = new ParenthesisPipe();
    expect(pipe).toBeTruthy();
  });
});
