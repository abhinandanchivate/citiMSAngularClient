import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { httpInterceptors } from './inteceptors';
import { SubjectService } from './services/subject.service';
import { HighlightDirective } from './directives/highlight.directive';
import { ParenthesisPipe } from './pipes/parenthesis.pipe';

@NgModule({
  declarations: [HighlightDirective, ParenthesisPipe],
  imports: [CommonModule],
  providers: [httpInterceptors, SubjectService],
  exports: [HighlightDirective, ParenthesisPipe],
})
export class SharedModule {}
